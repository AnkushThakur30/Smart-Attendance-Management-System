import { adminAnalyticsHandler } from "@/server/handlers";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(req: Request) {
  return adminAnalyticsHandler(req);
}
